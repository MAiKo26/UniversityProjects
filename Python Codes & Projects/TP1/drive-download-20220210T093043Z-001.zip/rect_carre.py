# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:12:19 2019

@author: dell
"""

#! /usr/bin/env python
# -*- coding: Latin-1 -*-
# Exemple repris et adaptÃ© de http://inforef.be/swi/download/cours_python.zip


class Point:
    """point mathÃ©matique"""
    def __init__(self, x, y):
        self.x = x
        self.y = y

    # MÃ©thode appelÃ©e quand on fait p1+p2  
    def __add__(self,other):
        p = Point(self.x+other.x,self.y+other.y)
        return p

    def __str__(self):
        return "x-value " + str(self.x) + " y-value " + str(self.y)

class Rectangle:
    """rectangle"""
    def __init__(self, ang, lar, hau):
        self.ang = ang
        self.lar = lar
        self.hau = hau

    def trouveCentre(self):
        xc = self.ang.x + self.lar /2
        yc = self.ang.y + self.hau /2
        return Point(xc, yc)

    

class Carre(Rectangle):
    """carrÃ© = rectangle particulier"""
    def __init__(self, coin, cote):
        Rectangle.__init__(self,
               coin, cote, cote)
        self.cote = cote

    def surface(self):
        return self.cote**2

###########################
## Programme principal : ##
        
# coord. de 2 coins sup. gauches :  
csgR = Point(40,30)
csgC = Point(10,25)
print(csgR+csgC)

# "boÃ®tes" rectangulaire et carrÃ©e : 
boiteR = Rectangle(csgR, 100, 50)
boiteC = Carre(csgC, 40)

# CoordonnÃ©es du centre pour chacune :
cR = boiteR.trouveCentre()
cC = boiteC.trouveCentre()

print ("centre du rect. :", cR.x, cR.y)
print ("centre du carre:", cC.x, cC.y)

print ("surf. du carre :",end=" ") # end=" " pour éviter de passer à la ligne
print (boiteC.surface())