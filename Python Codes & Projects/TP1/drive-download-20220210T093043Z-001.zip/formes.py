# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:11:51 2019

@author: dell
"""

#! /usr/bin/env python
# -*- coding: Latin-1 -*-
# Exemple repris de http://inforef.be/swi/download/cours_python.zip

class Rectangle:
    "Classe de rectangles"
    def __init__(self, longueur =0, largeur =0):
        self.L = longueur
        self.l = largeur
        self.nom ="rectangle"

    def perimetre(self):
        return "(%d + %d) * 2 = %d" % (self.L, self.l, 
                                             (self.L + self.l)*2)
    def surface(self):
        return "%d * %d = %d" % (self.L, self.l, self.L*self.l)

    def mesures(self):
        print ("Un %s de %d sur %d" % (self.nom, self.L, self.l))
        print ("a une surface de %s" % (self.surface()),end=" ")
        print ("et un perimetre de %s\n" % (self.perimetre()), end=" ")

# Classe heritant de la classe Rectangle
class Carre(Rectangle):
    "Classe de carrÃ©s"
    def __init__(self, cote):
        Rectangle.__init__(self, cote, cote)
        self.nom ="carre"

if __name__ == "__main__":
    r1 = Rectangle(15, 30)
    r1.mesures()    
    c1 = Carre(13)
    c1.mesures()