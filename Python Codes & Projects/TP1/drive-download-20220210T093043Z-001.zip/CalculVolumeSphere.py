# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:08:01 2019

@author: dell
"""

# Exercice repris et adaptÃ© de {\it Apprendre \'a programmer avec Python} de G\'erard Swinnen, 2009

from math import  *

def cube(n):
    return n**3

def volumeSphere(r):
    return 4 * pi * cube(r)

r=int(input('Saisir un rayon :'))
print("Le volume de la sphere vaut :", volumeSphere(r))