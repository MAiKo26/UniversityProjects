# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:10:27 2019

@author: dell
"""

# Exemple repris et adapté de http://inforef.be/swi/download/cours_python.zip
# Instructions composées <while> - <if> - <elif> - <else>

print('Choisissez un nombre de 1 à 3 (ou zéro pour terminer) :')
a = int(input()) # input() permet de saisir une chaine de caractres au clavier - int(input()) convertit la saisie en entier
# on aurait pu écrire a = int(input(Choisissez un nombre de 1 à 3 (ou zéro pour terminer) :')) 
while a != 0:           # l'opérateur != signifie "différent de"
    if a == 1:
        print("Vous avez choisi un!")
    elif a == 2:
        print("Vous préférez le deux!")
    elif a == 3:
        print("Vous optez pour le plus grand des trois!")
    else :
        print("Un nombre entre UN et TROIS, s.v.p.!!")
    a = int(input('Choisissez un nombre de 1 à 3 (ou zéro pour terminer) : '))
print("Vous avez entré zéro!")
print("L'exercice est donc terminé.")