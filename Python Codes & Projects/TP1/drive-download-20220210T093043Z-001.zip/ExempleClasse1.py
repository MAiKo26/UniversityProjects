# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:10:02 2019

@author: dell
"""

#! /usr/bin/env python
# -*- coding:Utf-8 -*-
# Exemple repris et adaptÃ© de http://inforef.be/swi/download/cours_python.zip

# DÃ©finition d'une classe 
class CompteBancaire(object):
    # Constucteur de la classe
    def __init__(self, nom ='Dupont', solde =1000):
        self.nom, self.solde = nom, solde
         
    # MÃ©thode de classe
    def depot(self, somme):
        self.solde = self.solde + somme

    # MÃ©thode de classe
    def retrait(self, somme):
        self.solde = self.solde - somme

    # MÃ©thode de classe
    def affiche(self):
        print("Le solde du compte bancaire de %s est de %s euros." %\
              (self.nom, self.solde))

    # MÃ©thode appelÃ© si print est appliquÃ© Ã  l'objet
    def __str__(self):
        return "Le solde du compte bancaire de %s est de %s euros." %\
              (self.nom, self.solde)
              
    def getNom(self):
        return self.nom
              
# Programme de test :
# __name__ permet d'indiquer si le programme est exÃ©cutÃ© en tant que programme autonome (les instructions qui suivent doiven Ãªtre exÃ©cutÃ©es) 
# ou en tant que bibliothÃ¨que de classes (les insctructions suivantes sont ignorÃ©es)
if __name__ == '__main__':
    c1 = CompteBancaire('Duchmol', 800)
    c1.depot(350)
    c1.retrait(200)
    c1.affiche()
    print(c1.nom)