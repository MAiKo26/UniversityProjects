# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:14:07 2019

@author: dell
"""

# Repris de A Quick, Painless Tutorial on the Python Language} de Norman Matloff
# reads in the text file whose name is specified on the command line,
# and reports the number of lines and words

import sys
def checkline():
   global l
   global wordcount
   w = l.split()
   wordcount += len(w)

wordcount = 0
f = open(sys.argv[1])
flines = f.readlines()
linecount = len(flines)
for l in flines:
   checkline()
print 'nombre de lignes : ', linecount, ' - nombre de mots : ', wordcount