# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:08:52 2019

@author: dell
"""



def copieFichier(source, destination):
    "copie integrale d'un fichier"
    fs = open(source, 'r')
    fd = open(destination, 'w')
    while 1:
        txt = fs.read(50)
        if txt =="":
            break
        fd.write(txt)
    fs.close()
    fd.close()
    return

copieFichier("test.txt","test3.txt")