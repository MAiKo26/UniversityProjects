# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:09:37 2019

@author: dell
"""

# Repris de {\it Apprendre \'a programmer avec Python} de G\'erard Swinnen, 2009


def existe(fname):
    try:
        f = open(fname,'r')
        f.close()
        return 1
    except:
        return 0

filename = input("Veuillez entrer le nom du fichier : ")

if existe(filename):
    print("Ce fichier existe bel et bien.")
else:
    print("Le fichier", filename, "est introuvable.")