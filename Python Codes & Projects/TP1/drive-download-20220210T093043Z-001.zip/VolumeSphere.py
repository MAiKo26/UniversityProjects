# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 16:10:59 2019

@author: dell
"""

# Exercice repris de {\it Apprendre \'a programmer avec Python} de G\'erard Swinnen, 2009
#! /usr/bin/env python
# -*- coding:Utf8 -*-

def cube(n):
    return n**3

def volumeSphere(r):
    return 4 * 3.1416 * cube(r) / 3

r = input()
print ('Le volume de cette sphère vaut', volumeSphere(r))